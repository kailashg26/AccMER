CUDA_VISIBLE_DEVICES=3 python src/main.py --config=ow_qmix --env-config=stag_hunt with env_args.map_name=stag_hunt env_args.miscapture_punishment=0  epsilon_anneal_time=100000 t_max=1050000 runner=parallel batch_size_run=8 buffer_size=1000 batch_size=128 obs_agent_id=True
sleep 3
CUDA_VISIBLE_DEVICES=3 python src/main.py --config=ow_qmix --env-config=stag_hunt with env_args.map_name=stag_hunt env_args.miscapture_punishment=0  epsilon_anneal_time=100000 t_max=1050000 runner=parallel batch_size_run=8 buffer_size=1000 batch_size=128 obs_agent_id=True
sleep 3
CUDA_VISIBLE_DEVICES=3 python src/main.py --config=ow_qmix --env-config=stag_hunt with env_args.map_name=stag_hunt env_args.miscapture_punishment=0  epsilon_anneal_time=100000 t_max=1050000 runner=parallel batch_size_run=8 buffer_size=1000 batch_size=128 obs_agent_id=True
sleep 3
